package com.example.restaurantsapp;

public class UserOrders {

    private String userName;
    private String customerOrder;

    public UserOrders(String UserName,String customerOrder){
          this.userName = userName;
          this.customerOrder = customerOrder;
    }
    public String getUserName(){
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCustomerOrder() {
        return customerOrder;
    }

    public void setCustomerOrder(String customerOrder) {
        this.customerOrder = customerOrder;
    }
}
