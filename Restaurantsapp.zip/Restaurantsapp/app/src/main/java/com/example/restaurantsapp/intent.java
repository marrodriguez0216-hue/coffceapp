package com.example.restaurantsapp;

import android.content.Intent;

public class intent extends Intent {
    public intent(MainActivity mainActivity, Class<menuOrder> menuOrderClass) {
    }
}
