package com.example.restaurantsapp;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class menuOrder extends AppCompatActivity {
    ImageButton black_ice;
    ImageButton coffce;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_order);
        black_ice = findViewById(R.id.black_ice);
        coffce = findViewById(R.id.coffce);

         black_ice.setOnClickListener(v -> );
         coffce.setOnClickListener(v);



        });
    }
}