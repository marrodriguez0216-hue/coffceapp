package com.example.restaurantsapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 EditText customerName;
  Button startOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customerName = findViewById(R.id.customerName);
        startOrder = findViewById(R.id.startOrder);
        startOrder.setOnClickListener(v -> ); {

            String name = customerName.getText().toString();
            intent intent = new intent(MainActivity.this, menuOrder.class);
            startActivity(intent);


        });
    }
}



