package com.example.restaurantsapp;

public class UserInformation {
    private String userName;
    private String userPassword;

    public UserInformation(String userName,String userPassword) {

    this.userName =userName;
    this.userPassword =userPassword;
}
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserPassword() {
        return userPassword;
    }
    public void setUserPassword() {
        this.userPassword = userPassword;
    }
}
